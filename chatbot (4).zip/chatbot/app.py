"""
app.py

Flask backend for MovieChatBot.
Receives chat messages from the frontend, sends them to the Gemini API
along with the system prompt from chatbot_config.py, and returns the
model's reply as JSON.
"""

import os

from dotenv import load_dotenv
from flask import Flask, render_template, request, jsonify
from google import genai
from google.genai import types

from chatbot_config import SYSTEM_PROMPT, CHATBOT_NAME

# Load environment variables from .env
load_dotenv()

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
MODEL_NAME = "gemini-3.1-flash-lite"

if not GEMINI_API_KEY:
    raise RuntimeError(
        "GEMINI_API_KEY is not set. Add it to your .env file before running the app."
    )

client = genai.Client(api_key=GEMINI_API_KEY)

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html", chatbot_name=CHATBOT_NAME)


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    user_message = (data.get("message") or "").strip()

    if not user_message:
        return jsonify({"error": "Message cannot be empty."}), 400

    try:
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=user_message,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
            ),
        )
        reply_text = response.text or "Sorry, I couldn't come up with a reply."
    except Exception:
        reply_text = (
            "Something went wrong while reaching the movie database. "
            "Please try again in a moment."
        )

    return jsonify({"reply": reply_text})


if __name__ == "__main__":
    app.run(debug=True)
